# 时光足迹恢复说明

此压缩包保存每条足迹的原始 `post.json` 和该条目选中的原始图片。

恢复或迁移时，将 `content/moments/` 整体解压回站点源码的同名目录，再运行：

```powershell
python scripts/build_moments.py
```

生成的 `dist/data/moments.json`、`dist/data/moments-backup.zip` 与 `dist/assets/moments/` 可随静态站点一同发布。请另外备份本压缩包和源码中的 `content/moments/`。
